<?php

$conn = mysqli_connect("localhost", "root", "", "college");
if (!$conn) {
    die("Data Base error");
}
?>